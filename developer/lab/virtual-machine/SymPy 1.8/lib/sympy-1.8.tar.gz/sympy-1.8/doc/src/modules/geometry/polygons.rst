Polygons
--------

.. module:: sympy.geometry.polygon

.. autoclass:: Polygon
   :members:

.. autoclass:: RegularPolygon
   :members:

.. autoclass:: Triangle
   :members:

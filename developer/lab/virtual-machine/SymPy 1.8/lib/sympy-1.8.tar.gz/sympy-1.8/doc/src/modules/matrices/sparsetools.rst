.. _matrices-sparsetools:

Sparse Tools
============

.. module:: sympy.matrices.sparsetools

.. automethod:: sympy.matrices.sparsetools::_doktocsr

.. automethod:: sympy.matrices.sparsetools::_csrtodok

.. automethod:: sympy.matrices.sparsetools::banded

=================
Body (Docstrings)
=================

Body
====

.. automodule:: sympy.physics.mechanics.body
   :members:

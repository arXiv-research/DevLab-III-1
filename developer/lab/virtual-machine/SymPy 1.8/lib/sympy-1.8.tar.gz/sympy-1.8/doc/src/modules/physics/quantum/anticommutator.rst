==============
Anticommutator
==============

.. automodule:: sympy.physics.quantum.anticommutator
   :members:

================================
Dimensions and dimension systems
================================

.. automodule:: sympy.physics.units.dimensions

.. autoclass:: Dimension
   :members:

.. autoclass:: DimensionSystem
   :members:

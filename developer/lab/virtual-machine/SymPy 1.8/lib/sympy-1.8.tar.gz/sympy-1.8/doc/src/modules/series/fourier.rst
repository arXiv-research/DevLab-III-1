Fourier Series
==============

Provides methods to compute Fourier series.

.. autoclass:: sympy.series.fourier::FourierSeries
   :members:

.. autofunction:: sympy.series.fourier::fourier_series

======
pytest
======

.. automodule:: sympy.testing.pytest
   :members:

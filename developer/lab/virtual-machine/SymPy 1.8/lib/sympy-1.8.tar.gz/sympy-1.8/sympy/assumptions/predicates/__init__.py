"""
Module to implement predicate classes.

Class of every predicate registered to ``Q`` is defined here.
"""

<!--- This is a generic template and may not be applicable in all cases. -->
<!--- Verify that your issue/request is not already reported on GitHub (https://github.com/bruderstein/nppPluginManager/issues)
If possible test that the latest release is affected too. -->
<!--- Try to follow it where possible. -->

### Description of the Issue
<!--- Provide a more detailed description to the issue itself -->

### Steps to Reproduce the Issue
<!--- Set of steps to reproduce this issue -->
1. 
2. 
3. 

### Expected Behavior
<!--- What did you expect to happen -->

### Actual Behavior
<!--- What actually happened -->

### Debug Information
<!--- Debug Info of N++ can be found under the "?" menu -->
<!--- nppPluginManager version can be found under plugin->PluginManager->About -->
<!--- other plugins involved and the version of them -->

<!--- Feel free to include any other info, such as screenshots, etc -->

#ifndef _PROXYINFO_H
#define _PROXYINFO_H

 
enum SAVECRED
{
	SAVECRED_UNKNOWN = 0,
	SAVECRED_YES = 1,
	SAVECRED_NO = 2
};




#endif
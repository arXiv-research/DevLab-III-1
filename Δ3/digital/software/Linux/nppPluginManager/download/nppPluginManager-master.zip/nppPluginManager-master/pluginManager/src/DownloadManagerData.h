#ifndef _DOWNLOADMANAGERDATA_H
#define _DOWNLOADMANAGERDATA_H

struct DownloadCallbackData
{
	DownloadManager* downloadManager;

};


#endif




#include <tchar.h>
#include <string>
#include <map>
#include <list>
#include <memory>
#include <set>
#include <sstream>


#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <commctrl.h>
#include <process.h>
#include <strsafe.h>

#include <functional>   // std::bind and std::function

typedef std::basic_string<TCHAR>			tstring;
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PluginManager.rc
//
#define IDD_CONFIGDIALOG                109
#define IDD_UPDATESNOTIFY               110
#define IDD_TABUPDATES                  111
#define IDD_TABINSTALLED                112
#define IDD_TABAVAILABLE                113
#define IDD_PROGRESSDIALOG              114
#define IDD_PLUGINMANAGER_DLG           115
#define IDB_BITMAP1                     121
#define IDC_BUTTON1                     1001
#define IDC_DOWNLOAD                    1001
#define IDC_BUTTONUPDATE                1001
#define IDC_BUTTONINSTALL               1001
#define IDC_BUTTONREMOVE                1001
#define IDC_SETTINGS                    1001
#define IDC_UPDATE                      1001
#define IDC_LISTUPDATES                 1009
#define IDC_PLUGINTABCTRL               1010
#define IDC_LISTAVAILABLE               1011
#define IDC_LISTINSTALLED               1012
#define IDC_EDIT1                       1013
#define IDC_EDITUPDATE                  1013
#define IDC_EDITAVAILABLE               1013
#define IDC_EDITINSTALLED               1013
#define IDC_PROXYADDRESS                1013
#define IDC_PROGRESSCURRENT             1014
#define IDC_PROGRESSOVERALL             1015
#define IDC_LABELCURRENT                1016
#define IDC_PROXYPORT                   1017
#define IDC_NOTIFY                      1018
#define IDC_NOTIFY2                     1019
#define IDC_SHOWUNSTABLE                1019
#define IDC_IGNORE                      1020
#define IDC_INSTALLALLUSERS             1020
#define IDC_BUTTON3                     1021
#define IDC_REINSTALL                   1021
#define IDC_FORCEHTTP                   1021
#define IDC_BUTTON2                     1022
#define IDC_USEDEVPLUGINSLIST           1022
#define IDC_USEDEVPLUGINLIST            1022
#define IDC_UPDATEDESC                  1023
#define IDC_DAYSTOCHECK                 1024
#define IDC_INFOTEXT                    1026
#define IDC_LOGO                        1027
#define IDC_NBCLINK                     1030
#define IDC_WHYISTHISHERE               1031
#define IDC_PLUGINLISTHOSTING           1033
#define IDC_NEXINTOBUSINESSCLOUD        1034
#define IDC_NBCLOGO                     1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        122
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

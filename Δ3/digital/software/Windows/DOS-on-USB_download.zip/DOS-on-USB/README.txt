DOS-on-USB (C)2008 James Holmes

Thanks for downloading the DOS-on-USB tool!

Information regarding this tool can be found at:
http://jamesonline.ca/support

============================================================

Recomendations:

For USB drives between 16MB and 2GB.


It is recomended to print off these instructions.


This utility requires your computer to be USB-Bootable,
You will have to enter BIOS to make these changes.

DO NOT CHANGE ANYTHING ELSE IN BIOS!

Also, you must change the boot order on all
the computers you wish to use your USB DOS drive on.


The Quick 30-step method:

============================================================

Setup instructions:

1.  Extract contents of archive to desktop

2.  Plug in your USB memory key

3.  Open James' Format Tool.exe

4.  Select your USB drive under "Device"

5.  Select FAT file system

6.  Type in a label for the drive

7.  Select "Format Device"

8.  Select "Create a DOS startup disk"

9.  Locate DOS files in the /DOS-on-USB/boot/ directory

10. Be sure that you have removed all important files
    off of your USB key!

11. Click "Start"

12. After the format has completed sucessfully, copy all
    of \DOS-on-USB\ to the root directory of your USB Drive

13. Hibernate or shut-down your computer

14. Boot up your computer, with the USB drive plugged in.

15. Enter your computer's BIOS
    (usually F1, F8, F12, DEL, or ESC)

16. Navigate to the Boot Order section

17. Bring USB to the top of the list, and save changes

18. After a reboot, you will hopefully come to a DOS-style
    screen that will tell you that DOS-on-USB has loaded

19. To continue installing DOS, press any key

20. You should hopefully come to the DOS setup wizard

21. Follow all prompts (click OK)

22. When it asks for the location of setup files, type:

	C:\dos\DOS71\

23. Say YES to rewriting the MBR

24. When asked for the install location, type:

	C:\dos71

25. When asked what type of installation: select
    Full Installation, then deselect Addon Package

26. Say YES to Access DOS

27. Continue to install DOS 7.1, then reboot

28. Unplug the USB Drive before it loads to enter Windows

29. Plug in, and delete the \dos\ and \boot\ folders
    on your USB drive

30. Complete!

============================================================

I will provide support for my product, but not for your BIOS

For more information, please contact:

info@jamesonline.ca
http://jamesonline.ca/support